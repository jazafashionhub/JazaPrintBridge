package com.jazafashionhub.printbridge;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.widget.Toast;
import android.app.Activity;
import androidx.core.content.FileProvider;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

public class MainActivity extends Activity {
    @Override public void onCreate(Bundle b) { super.onCreate(b); handle(getIntent()); }
    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); setIntent(i); handle(i); }

    private void handle(Intent i) {
        Uri u = i == null ? null : i.getData();
        if (u == null || !"jazaprinter".equalsIgnoreCase(u.getScheme()) || !"print".equalsIgnoreCase(u.getHost())) {
            return;
        }
        String pdf = u.getQueryParameter("url");
        if (pdf == null || pdf.trim().isEmpty()) { toast("PDF URL missing"); return; }
        new Thread(() -> downloadAndOpen(pdf)).start();
    }

    private void downloadAndOpen(String urlString) {
        File dir = new File(getCacheDir(), "pdf");
        if (!dir.exists()) dir.mkdirs();
        File out = new File(dir, "label_" + System.currentTimeMillis() + ".pdf");
        try {
            HttpURLConnection c = (HttpURLConnection) new URL(urlString).openConnection();
            c.setConnectTimeout(20000); c.setReadTimeout(30000); c.setInstanceFollowRedirects(true);
            c.setRequestProperty("User-Agent", "JazaPrintBridge/1.0");
            if (c.getResponseCode() < 200 || c.getResponseCode() >= 300) throw new IOException("HTTP " + c.getResponseCode());
            try (InputStream in = c.getInputStream(); OutputStream os = new FileOutputStream(out)) {
                byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) != -1) os.write(buf, 0, n);
            } finally { c.disconnect(); }
            Uri contentUri = FileProvider.getUriForFile(this, "com.jazafashionhub.printbridge.fileprovider", out);
            Intent open = new Intent(Intent.ACTION_VIEW);
            open.setDataAndType(contentUri, "application/pdf");
            open.setClassName("com.print.label", "com.print.label.PreviewFileActivity5");
            open.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            runOnUiThread(() -> {
                try { startActivity(open); }
                catch (Exception e) { toast("Print Label app could not open the PDF"); }
            });
        } catch (Exception e) { runOnUiThread(() -> toast("Could not download PDF: " + e.getMessage())); }
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_LONG).show(); }
}
